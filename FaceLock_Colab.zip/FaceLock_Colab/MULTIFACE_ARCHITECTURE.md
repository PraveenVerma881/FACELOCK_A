# Multi-person FaceLock: Architecture and Method

## Goal

Standard FaceLock optimizes an image-level perturbation for one portrait. Multi-person FaceLock detects visible faces and allocates perturbation to those regions. It first optimizes each face independently, then jointly refines the composition so the least-protected identity is not hidden by an average score.

## End-to-end flow

```mermaid
flowchart TD
    A[Input RGB image] --> B[Normalize to [-1, 1]]
    B --> C[OpenCV Haar face detection]
    C --> D[Pad boxes and build soft face masks]
    D --> E[Crop each face region]
    E --> F[Independent FaceLock warm-start per crop]
    F --> G[Weighted mask blend of local perturbations]
    G --> H[Joint PGD refinement on full image]
    H --> I[VAE encode/decode reconstruction]
    I --> J[Align each face and extract AdaFace embeddings]
    J --> K[Worst-face identity + quality + smoothness + boundary loss]
    K --> H
    H --> L[Project to epsilon budget and face-mask union]
    L --> M[Protected image]
```

## Models

- **Face detector:** OpenCV's `haarcascade_frontalface_default.xml`, provided by the declared OpenCV dependency. Detected boxes are padded before crop optimization. Soft elliptical masks fade each crop perturbation into the surrounding image.
- **Face aligner:** `minchul/cvlface_DFA_mobilenet`. It aligns crops before recognition to reduce sensitivity to face position and pose.
- **Identity encoder:** `minchul/cvlface_adaface_vit_base_kprpe_webface4m`. AdaFace maps an aligned crop to an identity embedding. Cosine similarity between a clean face and its protected reconstruction is the privacy signal; lower similarity is the target.
- **Perceptual metric:** VGG-based LPIPS. It discourages visible changes between the input and its VAE reconstruction.
- **Image representation:** The VAE attached to the selected image-to-image editing pipeline. Its encoder and decoder provide the differentiable optimization surrogate.

The Hugging Face CVLFace repositories are loaded using the existing cache and token settings (`HF_HOME` and `HUGGINGFACE_HUB_TOKEN`).

## Face-wise strategy

For an input $x$, detection returns $N$ face boxes $b_i$. A padded crop $c_i$ is extracted for each box and independently optimized with the existing FaceLock loss. Crop dimensions are rounded up to VAE-compatible multiples of eight for optimization, then the resulting crop perturbation is resized back to its original region.

Each local perturbation $\delta_i$ is multiplied by a soft mask $m_i$ and a size-based weight $\alpha_i$. Overlapping contributions are normalized by the sum of their weights:

$$
\delta_0(p) = \frac{\sum_i \alpha_i m_i(p)\delta_i(p)}{\max(\sum_i \alpha_i m_i(p),\,\varepsilon_0)}, \qquad
x' = \operatorname{clip}(x + \delta_0).
$$

Here $\varepsilon_0$ is a small numerical denominator, not the perturbation budget. Smaller detected faces receive a moderately lower weight, with a floor so they still participate in optimization. The joint-stage perturbation is restricted to the union of masks, leaving the background unchanged.

## Joint objective

At each refinement step the selected editor's VAE reconstructs the current protected image, $\hat{x}=D(E(x+\delta))$. For every detected face, AdaFace compares the aligned reconstructed crop with the corresponding clean crop. The implementation minimizes:

$$
\mathcal{L}(\delta) =
\max_i s_i(\hat{x},x)
+ 0.2\,\mathcal{L}_{\mathrm{latent}}
+ \mathcal{L}_{\mathrm{LPIPS}}
+ 0.02\,\mathcal{L}_{\mathrm{TV}}
+ 0.1\,\mathcal{L}_{\mathrm{boundary}},
$$

where $s_i$ is cosine identity similarity. Minimizing the maximum similarity targets the worst-protected face rather than letting strong results for one face compensate for weak results for another. The latent term is mean-squared distance between current and clean VAE latents. The TV term discourages high-frequency pixel noise. The boundary term penalizes perturbation magnitude near mask transitions. LPIPS preserves perceived image quality.

The update is projected after every step:

$$
\delta \leftarrow \operatorname{clip}_{[-\epsilon,\epsilon]}
\left(\delta - \eta\,\operatorname{sign}(\nabla_\delta\mathcal{L})\right)\odot m,
$$

where $m$ is the union of face masks, $\epsilon$ is `--attack_budget`, and $\eta$ is the decayed `--step_size`. Independent crop optimization supplies face-specific starting points; joint refinement accounts for overlap and optimizes the worst face under one image-level budget.

## Rectified-flow models

Diffusion and rectified-flow editors differ in their sampling processes. The implementation does **not** differentiate through that full process. With `--target_model=rectified-flow`, `AutoPipelineForImage2Image` loads the checkpoint and its VAE is used by the crop and joint losses. This is the proposal's lower-memory VAE-surrogate route. It is differentiable, but by itself does not guarantee that an edited Flux or Stable Diffusion 3 output loses identity.

Validate by editing both clean and protected images with the target pipeline, prompts, strengths, and guidance settings, then compare face verification similarity and image-quality metrics. A future sampler-aware extension could unroll a small number of rectified-flow steps or use periodic black-box output evaluation with expectation over prompts, timesteps, and guidance settings.

## Usage

Single image:

```bash
python defend.py --input_path group.jpg --output_path protected.png \
  --defend_method multiface --attack_budget 0.03 --step_size 0.01 --num_iters 100
```

Rectified-flow VAE surrogate:

```bash
python defend.py --input_path group.jpg --output_path protected.png \
  --defend_method multiface --target_model rectified-flow \
  --model_id black-forest-labs/FLUX.1-dev
```

The existing Hugging Face cache/token setup is required for the CVLFace models, and access to gated editor checkpoints must be configured separately. The multi-face implementation expects one image per optimization call; the directory command processes images one at a time.

## Current limitations

- Haar frontal-face detection is a lightweight baseline. It may miss profile faces, small faces, strong occlusions, or faces in difficult lighting. Check for missed people; replace the detector with RetinaFace or InsightFace for demanding datasets.
- Face crops are determined once from the clean input. Large geometric changes caused by an editor may move a face outside its original crop.
- The independent warm-start calls the existing FaceLock optimizer for each crop, followed by full joint optimization. Runtime therefore grows with face count.
- Rectified-flow support currently means VAE-surrogate optimization, not full trajectory-aware or black-box optimization. Evaluate with the actual target editor before drawing robustness conclusions.