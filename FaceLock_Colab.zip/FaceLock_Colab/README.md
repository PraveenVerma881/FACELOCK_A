# FaceLock

[![arXiv](https://img.shields.io/badge/arXiv-2411.16832-b31b1b.svg)](https://arxiv.org/abs/2411.16832) [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

<table align="center">
  <tr>
    <td align="center"> 
      <img src="assets/teaser.png" alt="Image 1" style="width: 700px;"/> 
      <br>
      <em style="font-size: 18px;">  <strong style="font-size: 18px;">Figure 1:</strong> An illustration of adversarial perturbation generation for safeguarding personal images.</em>
    </td>
  </tr>
</table>

Welcome to the official repository for the paper, [Edit Away and My Face Will not Stay: Personal Biometric Defense against Malicious Generative Editing](https://arxiv.org/abs/2411.16832).


## Abstract

Recent advancements in diffusion models have made generative image editing more accessible than ever. While these developments allow users to generate creative edits with ease, they also raise significant ethical concerns, particularly regarding malicious edits to human portraits that threaten individuals' privacy and identity security. Existing general-purpose image protection methods primarily focus on generating adversarial perturbations to nullify edit effects. However, these approaches often exhibit instability to protect against diverse editing requests. In this work, we introduce a novel perspective to personal human portrait protection against malicious editing. Unlike traditional methods aiming to prevent edits from taking effect, our method, **FaceLock**, optimizes adversarial perturbations to ensure that original biometric information---such as facial features---is either destroyed or substantially altered post-editing, rendering the subject in the edited output biometrically unrecognizable. Our approach innovatively integrates facial recognition and visual perception factors into the perturbation optimization process, ensuring robust protection against a variety of editing attempts. Besides, we shed light on several critical issues with commonly used evaluation metrics in image editing and reveal cheating methods by which they can be easily manipulated, leading to deceptive assessments of protection. Through extensive experiments, we demonstrate that **FaceLock** significantly outperforms all baselines in defense performance against a wide range of malicious edits. Moreover, our method also exhibits strong robustness against purification techniques. Our work not only advances the state-of-the-art in biometric defense but also sets the foundation for more secure and privacy-preserving practices in image editing.

## Environment

We provide a [conda env file](environment.yml) for environment setup.

```bash
conda env create -f environment.yml
conda activate facelock
```

## Single Image Edit and Defend

We begin by presenting the code for image editing and defending applied to a single input image.

```bash
python edit.py --input_path ./portrait.jpg --prompt "Make the man look like the Joker" \
  --num_inference_steps 100 --image_guidance_scale 1.5 --guidance_scale 7.5 \
  --output_path ./edited/portrait_joker.png
```

Arguments explanation:

- `input_path` the path to the image to be edited
- `prompt` the instruction prompt used to edit the image
- `num_inference, image_guidance_scale, guidance_scale` configurations used to guide the image editing process
- `help` to view other arguments for image editing

```bash
python defend.py --input_path ./group.jpg --output_path ./protected/group_protected.png \
  --defend_method multiface --attack_budget 0.03 --step_size 0.01 --num_iters 100
```

Argument explanation:

- `input_path` the path to the image to be protected
- `defend_method` the selected defense method: `encoder`, `vae`, `cw`, `facelock`, or `multiface`
- `attack_budget, step_size, num_iters` hyper-parameters for the defend process
- `help` to view other arguments for defending a single image

## Scaling Up

Next, we extend this to demonstrate the code for handling image editing and defending across multiple images.

```bash
python main_edit.py --src_dir ./portraits --edit_dir ./edits \
  --num_inference_steps 100 --image_guidance_scale 1.5 --guidance_scale 7.5
```

Arguments explanation:

- `src_dir` the path to the directory of the source images to be edited
- `edit_dir` the path to the directory containing the edited images generated
- other arguments are similar to the single image editing version, use `help` to see more details

```bash
python main_defend.py --image_dir ./portraits --output_dir ./protected \
  --defend_method multiface --attack_budget 0.03 --step_size 0.01 --num_iters 100
```

Arguments explanation:

- `image_dir` the path to the directory of the source images to be protected
- `output_dir` the path to the directory containing the protected images generated
- other arguments are similar to the single image defending version, use `help` to see more details

## Multi-person FaceLock

### Quick commands and shell usage

Start in this `FaceLock` directory with the `facelock` environment active. The `run_model.sh` launcher chooses the single-image or directory script based on whether its first input is a file or a directory:

```bash
./run_model.sh defend ./group.jpg ./protected multiface --num_iters 100
./run_model.sh defend ./portraits ./protected multiface --num_iters 100
./run_model.sh edit ./portrait.jpg "Make the man look like the Joker" ./edited.jpg --num_inference_steps 100
./run_model.sh edit-dir ./portraits ./edits --num_inference_steps 100
```

Quote prompts containing spaces. Use the real path after an option; don't put `$` before a path. `${...}` is shell variable syntax and is not a way to wrap arbitrary paths or prompts. Square brackets in old command examples meant optional arguments and should not be typed. `main_edit.py --src_dir` expects a **directory**; `edit.py --input_path` expects one **image file**.

`utils.py` must stay in this project directory next to `main_edit.py` and `main_defend.py`. If Python reports `ModuleNotFoundError: utils`, check that you are running the script from this complete project and that `utils.py` exists there.

The `multiface` method detects visible faces, optimizes each crop independently, blends the perturbations with soft masks, and jointly refines the image to minimize the highest remaining identity similarity. Background pixels are not perturbed. Detection uses OpenCV's frontal-face Haar cascade, which may miss profile, small, or heavily occluded faces; inspect detections for challenging images.

For a short, command-by-command walkthrough of editing and protection, see [GETTING_STARTED.pdf](GETTING_STARTED.pdf).

```bash
python defend.py --input_path=group.jpg --output_path=group_protected.png \
  --defend_method=multiface --attack_budget=0.03 --step_size=0.01 --num_iters=100
```

The batch command uses the same defense:

```bash
python main_defend.py --image_dir=images --output_dir=protected --defend_method=multiface
```

Multi-face optimization is per image; it does not train or fine-tune a reusable neural network. The identity encoder, aligner, and editor VAE stay frozen. Each output image gets its own optimized perturbation, which is the reproducible optimization pipeline described in the project proposal. For faster runs, reduce face warm-start steps or stop once every detected face meets a chosen similarity threshold:

`main_defend.py` loads only the editor VAE for defense, freezes model weights while retaining gradients to the input image, and batches warm-start crops with matching padded dimensions. Progress metrics are synchronized less often. Its `efficiency.csv` now records comparable per-image runtime and peak memory for both `facelock` and `multiface`, plus model initialization time.

```bash
python defend.py --input_path=group.jpg --defend_method=multiface \
  --warm_start_iters=5 --num_iters=60 --early_stop_similarity=0.35
```

`--warm_start_iters` defaults to 25 (per face); set it to `0` to skip independent warm starts. `--early_stop_similarity` is optional and uses the maximum clean-versus-protected AdaFace cosine similarity across detected faces. A lower value is a stricter target, and it may not be reached within the iteration budget. Without `--output_path`, the single-image command writes `<input>_protected.png` alongside the input.

### Rectified-flow editors

Rectified-flow image-to-image checkpoints can be selected through Diffusers' `AutoPipelineForImage2Image`:

```bash
python defend.py --input_path=group.jpg --output_path=group_protected.png \
  --defend_method=multiface --target_model=rectified-flow \
  --model_id=black-forest-labs/FLUX.1-dev
```

This uses the selected model's VAE as a differentiable surrogate, as described in the proposal. It does not backpropagate through the rectified-flow sampling trajectory. Checkpoint availability depends on the installed Diffusers version and Hugging Face access. Evaluate protected images with the actual editor, prompts, and settings before drawing robustness conclusions.

### Models and objective

The implementation uses OpenCV Haar for face detection, CVLFace DFA MobileNet for alignment, CVLFace AdaFace ViT for identity embeddings, the chosen editor's VAE for latent/reconstruction losses, and VGG-LPIPS for perceptual quality. The joint objective minimizes the maximum per-face cosine similarity, plus latent reconstruction, LPIPS, total-variation, and mask-boundary penalties. After each update, the perturbation is projected to the configured $L_\infty$ budget and restricted to the union of soft face masks. See [MULTIFACE_ARCHITECTURE.md](MULTIFACE_ARCHITECTURE.md) for the architecture diagram, loss formulation, model flow, and current limitations.

### Optimization details

`multiface_facelock` in `methods.py` calls `detect_face_boxes` to find faces, then calls the existing `facelock` optimizer once per face to create a local warm start. Each crop's soft mask and area-based weight are blended into one perturbation. During image-level refinement, all reconstructed and clean face crops are aligned and scored as a batch; the loss minimizes the worst remaining face score:

$$
\mathcal{L}=\max_i s_i + 0.2\,\mathcal{L}_{\mathrm{latent}} + \mathcal{L}_{\mathrm{LPIPS}} + 0.02\,\mathcal{L}_{\mathrm{TV}} + 0.1\,\mathcal{L}_{\mathrm{boundary}}.
$$

Here, $s_i$ is the clean-versus-reconstructed AdaFace cosine similarity for face $i$; lower is the privacy target. The latent term is VAE latent MSE, LPIPS penalizes perceptual change, TV discourages high-frequency perturbations, and the boundary term discourages abrupt changes at mask edges. `torch.autograd.grad` computes the gradient; each iteration applies a decaying sign-gradient step, clips the perturbation to the $L_\infty$ budget, and masks it to detected face regions. The background is therefore unchanged.

| Setting | Default | Use in `multiface_facelock` |
| --- | ---: | --- |
| Perturbation budget (`--attack_budget`) | 0.03 | Joint $L_\infty$ bound; crop warm-start budget is scaled by face size |
| Initial step size (`--step_size`) | 0.01 | Sign-gradient step, decayed toward 1% of its initial value |
| Joint iterations (`--num_iters`) | 100 | Full-image worst-face refinement |
| Warm-start iterations per face | 25 (CLI) | Calls to `facelock` for each detected face; configurable with `--warm_start_iters` |
| Joint identity objective | $\max_i s_i$ | Targets the least-protected face, not the mean face score |

These values describe the current implementation, not measured performance. With the defaults, the optimizer reports the current `worst_face_similarity` and LPIPS `quality` in its progress display, but it does not save a per-iteration loss history or a result CSV.

### Results

The table below reproduces the **single-face FACELOCK** result from Table 1 of the [CVPR 2025 paper](Wang_Edit_Away_and_My_Face_Will_not_Stay_Personal_Biometric_CVPR_2025_paper.pdf). It is a published reference, not a result for this repository's `multiface` implementation. The paper reports mean $\pm$ standard deviation over five editing seeds; its benchmark uses 2,000 CelebA-HQ portraits and 25 editing prompts.

| Method / provenance | CLIP-S $\downarrow$ | PSNR $\downarrow$ | SSIM $\downarrow$ | LPIPS $\uparrow$ | CLIP-I $\downarrow$ | FR $\downarrow$ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| FACELOCK, published single-face result | 0.114 $\pm$ 0.024 | 17.11 $\pm$ 2.36 | 0.589 $\pm$ 0.079 | 0.436 $\pm$ 0.065 | 0.648 $\pm$ 0.089 | 0.315 $\pm$ 0.109 |
| `multiface`, local workspace | Not measured | Not measured | Not measured | Not measured | Not measured | Not measured |

No protected multi-person output or metric CSV is currently present in this workspace, so there are no defensible local Multi-face scores to report yet. Do not interpret the published single-face row as a Multi-face result. The existing `evaluation/eval_facial.py` produces an image-level face similarity; for a multi-person privacy result, also report per-face similarity and the worst-face value $\max_i s_i$ on matched edits. Run the target editor on both clean and protected images with identical prompts, seeds, and settings, then calculate the quality and identity metrics over those matched outputs. See [Evaluation](#evaluation) for the available metric commands.

## Evaluation

We provide the evaluation code for computing the `PSNR, SSIM, LPIPS, CLIP-S, CLIP-I, FR` metrics mentioned in the paper.

```bash
cd evaluation
# PSNR metric
python eval_psnr.py --clean_edit_dir ./edits/clean --defend_edit_dirs ./edits/protected --seed 123
# SSIM metric
python eval_ssim.py --clean_edit_dir ./edits/clean --defend_edit_dirs ./edits/protected --seed 123
# LPIPS metric
python eval_lpips.py --clean_edit_dir ./edits/clean --defend_edit_dirs ./edits/protected --seed 123
# CLIP-S metric
python eval_clip_s.py --src_dir ./portraits --defend_edit_dirs ./edits/protected --seed 123 --clean_edit_dir ./edits/clean
# CLIP-I metric
python eval_clip_i.py --src_dir ./portraits --defend_edit_dirs ./edits/protected --seed 123 --clean_edit_dir ./edits/clean
# FR metric
python eval_facial.py --src_dir ./portraits --defend_edit_dirs ./edits/protected --seed 123 --clean_edit_dir ./edits/clean
```

These paths are examples: `./edits/clean/seed123/prompt0/` and `./edits/protected/budget_0.03/seed123/prompt0/` should contain matching image filenames.

For `PSNR`, `SSIM`, and `LPIPS`, the computations are performed between the edits on the protected images and the edits on the clean images. Therefore, the inputs `defend_edit_dirs` and `clean_edit_dir` are required.

For `CLIP-S`, the computation involves the source image, the edited image, and the edit prompt. To handle your unique instructions, you can modify [`utils.py`](utils.py). This requires additional input for the source image directory `src_dir`. If `clean_edit_dir` is provided, `CLIP-S` results will also be calculated for the edits on unprotected images.

For `CLIP-I` and `FR`, the computations use the source image and the edited image, sharing the same input settings as `CLIP-S`.

The scripts write `*_metric.csv` files to the current working directory. After running the metrics, combine the available CSVs into a PDF report:

```bash
python evaluation/generate_report.py \
  --metrics_dir . \
  --output_pdf evaluation/multiface_evaluation_report.pdf
```

### Multi-face privacy, robustness, and efficiency evaluation

First put original and protected images in separate directories with identical filenames. Generate protected images using `main_defend.py`; it writes `efficiency.csv` beside the protected outputs for both `facelock` and `multiface`, with per-image runtime, peak allocated GPU memory, and model initialization time. Multi-face rows also include detected face count, joint and warm-start steps. Then run:

```bash
python evaluation/eval_multiface.py \
  --clean_dir /data/group/clean \
  --protected_dir /data/group/protected/budget_0.03 \
  --output_dir evaluation/results \
  --runtime_csv /data/group/protected/budget_0.03/efficiency.csv \
  --verification_threshold 0.35
```

Set `--verification_threshold` to the threshold calibrated for the same AdaFace verifier and a stated false-accept rate on a held-out validation set. The example `0.35` is only a placeholder; do not report it as a benchmark threshold without calibration. The runner creates `per_face_privacy.csv` (similarity, similarity drop, thresholded verification attack success, and worst-face analysis by grouping), `image_quality.csv` (PSNR, SSIM, LPIPS, CLIP image similarity), `robustness.csv` (resize, center crop, JPEG quality 50, and blur), `efficiency.csv`, and face-box review images under `boundary_review/`. Inspect those review images for missed faces and visible mask edges. OpenCV Haar detection is used, so it can miss profiles or occluded faces.

For editing robustness, first generate matched edits of clean and protected images with the same prompts, seeds, and settings. Pass their directories with `--clean_edits_dir` and `--protected_edits_dir`; select `--edit_model_family rectified-flow` when those were produced by a rectified-flow editor. The runner writes per-image worst-face similarity and verification attack success to `editing_robustness.csv`. It measures the outputs; it does not launch diffusion or rectified-flow editing itself.

Closed-set top-1 re-identification accuracy requires real identity labels. Provide a CSV with columns `filename,face_index,identity_id` using the detected face ordering from the runner:

```bash
python evaluation/eval_multiface.py ... \
  --identity_manifest /data/group/identity_manifest.csv
```

Use identity-disjoint enrollment and evaluation splits for a defensible re-identification result. Without this manifest the runner omits re-identification accuracy rather than treating every face crop as a unique identity. WIDER FACE is useful for testing face-count/occlusion stress, but has no identity labels; the LFW link in `main.pdf` is better suited to identity verification. Download datasets separately and follow their licenses and usage terms.

To include the extended CSVs in the PDF report, point the report generator at the results directory:

```bash
python evaluation/generate_report.py \
  --metrics_dir evaluation/results \
  --output_pdf evaluation/results/multiface_report.pdf
```

The PDF reports local CSV-derived means separately from the published mean ± standard deviation comparison in Table 1 of the supplied CVPR 2025 paper. The paper's first scored baseline is retained under its printed combined label, `PhotoGuard Encoder attack`; those published single-face values are not Multi-face measurements. If no metric CSVs exist, the PDF marks local quantitative evaluation as pending. Local scores require matched clean/protected edit outputs and the evaluation inputs described above.

## Citation

If you find this repository helpful for your research, please consider citing our work:

```bibtex
@article{wang2024editawayfacestay,
      title={Edit Away and My Face Will not Stay: Personal Biometric Defense against Malicious Generative Editing}, 
      author={Hanhui Wang and Yihua Zhang and Ruizheng Bai and Yue Zhao and Sijia Liu and Zhengzhong Tu},
      journal={arXiv preprint arXiv:2411.16832}, 
}
```
