#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CONDA_ENV="${CONDA_ENV:-facelock}"

usage() {
    cat <<'USAGE'
Usage:
  ./run_model.sh defend <image-or-image-dir> <output-dir> [method] [options...]
  ./run_model.sh edit <input-image> <prompt> <output-image> [options...]
  ./run_model.sh edit-dir <input-image-dir> <output-dir> [options...]

Examples:
  ./run_model.sh defend ./group.jpg ./protected multiface --num_iters 100
  ./run_model.sh defend ./images ./protected multiface --num_iters 100
  ./run_model.sh edit ./portrait.jpg "Make the man look like the Joker" ./edited.jpg --num_inference_steps 100
  ./run_model.sh edit-dir ./portraits ./edits --num_inference_steps 100

The legacy form is supported: ./run_model.sh <image-or-dir> <output-dir> [method] [options...]
Use normal paths and quote prompts. Do not type ${...} or square-bracket notation from docs.
USAGE
}

fail() { echo "run_model.sh: $*" >&2; exit 2; }
[[ $# -gt 0 ]] || { usage >&2; exit 2; }
if [[ "$1" == "--help" || "$1" == "-h" ]]; then usage; exit 0; fi

mode=defend
if [[ "$1" == "defend" || "$1" == "edit" || "$1" == "edit-dir" ]]; then
    mode="$1"
    shift
fi

export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"

run_python() {
    if command -v conda >/dev/null 2>&1; then
        conda run --no-capture-output -n "$CONDA_ENV" python "$@"
    else
        python "$@"
    fi
}

if [[ "$mode" == edit ]]; then
    [[ $# -ge 3 ]] || { usage >&2; exit 2; }
    input_path="$1"; prompt="$2"; output_path="$3"; shift 3
    [[ -f "$input_path" ]] || fail "input image does not exist: $input_path"
    mkdir -p -- "$(dirname -- "$output_path")"
    run_python "$SCRIPT_DIR/edit.py" --input_path "$input_path" --prompt "$prompt" --output_path "$output_path" "$@"
    exit $?
fi

if [[ "$mode" == edit-dir ]]; then
    [[ $# -ge 2 ]] || { usage >&2; exit 2; }
    input_dir="$1"; output_dir="$2"; shift 2
    [[ -d "$input_dir" ]] || fail "input directory does not exist: $input_dir"
    [[ -f "$SCRIPT_DIR/utils.py" ]] || fail "utils.py is missing from $SCRIPT_DIR"
    mkdir -p -- "$output_dir"
    run_python "$SCRIPT_DIR/main_edit.py" --src_dir "$input_dir" --edit_dir "$output_dir" "$@"
    exit $?
fi

[[ $# -ge 2 ]] || { usage >&2; exit 2; }
input_path="$1"; output_dir="$2"
if [[ $# -ge 3 && "$3" != --* ]]; then
    defend_method="$3"
    shift 3
else
    defend_method=multiface
    shift 2
fi
extra_args=("$@")
[[ -e "$input_path" ]] || fail "input path does not exist: $input_path"
[[ -f "$SCRIPT_DIR/utils.py" ]] || fail "utils.py is missing from $SCRIPT_DIR"
mkdir -p -- "$output_dir"
export HF_HOME="${HF_HOME:-$HOME/.cache/huggingface}"

if [[ -f "$input_path" ]]; then
    stem="$(basename -- "$input_path")"
    stem="${stem%.*}"
    output_path="$output_dir/${stem}_protected.png"
    command=("$SCRIPT_DIR/defend.py" --input_path "$input_path" --output_path "$output_path" --defend_method "$defend_method" "${extra_args[@]}")
elif [[ -d "$input_path" ]]; then
    command=("$SCRIPT_DIR/main_defend.py" --image_dir "$input_path" --output_dir "$output_dir" --defend_method "$defend_method" "${extra_args[@]}")
else
    fail "input must be an image file or directory: $input_path"
fi

if [[ "$defend_method" == facelock || "$defend_method" == multiface ]]; then
    [[ -n "${HUGGINGFACE_HUB_TOKEN:-}" ]] || fail "set HUGGINGFACE_HUB_TOKEN before running FaceLock"
fi
run_python "${command[@]}"
